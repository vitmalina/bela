// This file runs in the devtools API and creates a panel
chrome.devtools.panels.create("Bela Automation", null, 'views/devtools/panel.html', function (panel) {
    // when panel is created
})